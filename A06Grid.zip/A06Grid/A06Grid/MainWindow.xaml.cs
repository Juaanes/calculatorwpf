﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace A06Grid
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        String operador = " ";
        double num1 = 0;
        double num2 = 0;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txtResult.Text = "0";
            num1 = 0;
            num2 = 0;
            operador = " ";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text.Length == 1) txtResult.Text = "0";
            else txtResult.Text = txtResult.Text.Substring(0, txtResult.Text.Length - 1);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if(txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "1";
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "2";
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "3";
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "4";
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "5";
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "6";
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "7";
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "8";
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "9";
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "0";
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + ",";
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "+";
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "-";
        }

        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "x";
        }

        private void Button_Click_16(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "/";
        }

        private void Button_Click_17(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + "(";
        }

        private void Button_Click_18(object sender, RoutedEventArgs e)
        {
            if (txtResult.Text == "0") txtResult.Text = "";
            txtResult.Text = txtResult.Text + ")";
        }
    }
}
